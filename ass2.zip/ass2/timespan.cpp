#include <iostream>
#include "timespan.h"

TimeSpan::TimeSpan(double currHours, double currMin, double currSec) {
    double tempTotal = 0;
    tempTotal += (currHours * 3600);
    tempTotal += (currMin * 60);
    tempTotal += currSec;

    totalSeconds = tempTotal;
}

int TimeSpan::getSeconds() const {
    // Gets the number of seconds in an hour:
    int hoursInSeconds = getHours() * 3600;

    // Gets the number of seconds in a minute:
    int minutesInSeconds = getMinutes() * 60;

    // Returns the total seconds for both hours and minutes:
    return (totalSeconds - hoursInSeconds - minutesInSeconds);
}

int TimeSpan::getMinutes() const {
    // Retrieves the number of seconds from an hour:
    int hours = getHours();

    // The remaining seconds from the total minutes:
    int remainingSeconds = totalSeconds - (3600 * hours);

    // Returns the minutes that is within 0-59:
    return (remainingSeconds / 60);
}

int TimeSpan::getHours() const {
    // Returns total number of seconds in an hour:
    return totalSeconds / 3600;
}

bool TimeSpan::operator == (const TimeSpan& time) const {
    bool status;

    // 'getHours' variagle is a memeber of 'ts'
    // 'time.getHours()' variable is a reference to the 'gethours' member of ts2/ts3
    if (getHours() == time.getHours() && getMinutes() == time.getMinutes() && getSeconds() == time.getSeconds()) {
        status = true;
    }

    else {
        status = false;
    }

    return status;
}

bool TimeSpan::operator != (const TimeSpan& time) const {
    bool status;

    if (getHours() != time.getHours() && getMinutes() != time.getMinutes() && getSeconds() != time.getSeconds()) {
        status = true;
    }

    else {
        status = false;
    }

    return status;
}

bool TimeSpan::operator > (const TimeSpan &time) const {
    bool status;
    if (totalSeconds > time.totalSeconds) {
        status = true;
    }

    else {
        status = false;
    }

    return status;
}

bool TimeSpan::operator < (const TimeSpan &time) const {
    bool status;
    if (totalSeconds < time.totalSeconds) {
        status = true;
    }

    else {
        status = false;
    }

    return status;
}

bool TimeSpan::operator >= (const TimeSpan &time) const {
    bool status;
    if (totalSeconds >= time.totalSeconds) {
        status = true;
    }

    else {
        status = false;
    }

    return status;
}

bool TimeSpan::operator <= (const TimeSpan &time) const {
    bool status;
    if (totalSeconds <= time.totalSeconds) {
        status = true;
    }

    else {
        status = false;
    }

    return status;
}

TimeSpan TimeSpan::operator + (const TimeSpan &time) const {
    TimeSpan temp(getHours() + time.getHours(), getMinutes() + time.getMinutes(), getSeconds() + time.getSeconds());
    return temp;
}

TimeSpan TimeSpan::operator - (const TimeSpan &time) const {
    TimeSpan temp(getHours() - time.getHours(), getMinutes() - time.getMinutes(), getSeconds() - time.getSeconds());
    return temp;
}

TimeSpan TimeSpan::operator * (int num) {
    TimeSpan temp(getHours() * num, getMinutes() * num, getSeconds() * num);
    return temp;
}


TimeSpan TimeSpan::operator += (const TimeSpan& time) {
    totalSeconds += time.totalSeconds;
    return *this;
}

TimeSpan TimeSpan::operator -= (const TimeSpan& time) {
    totalSeconds -= time.totalSeconds;
    return *this;
}


ostream &operator << (ostream &out, const TimeSpan &timeSpan) {
  out << timeSpan.getHours() << ":";
  out << timeSpan.getMinutes() << ":";
  out << timeSpan.getSeconds();

  return out;
}